<template>
   <div class="form-footer">
      <p class="info">2014~2018　　北京 上海 深圳 武汉 成都 西安　　　更新日期：2018-05-18</p>
   </div>
</template>
<script>
Vue.component("vp-footer-default", {
   template: template,
   props: [],
   data() {
      return {

      };
   },
   computed: {
      Menu: {
         get() {
            return store.state.Menu;
         },
      },
   },
   watch: {
   },
   methods: {
   },
   created() {
   },
   mounted() {},
});
</script>


<style lang="less">
@headerheight: 50px;
.form-footer {
   overflow: auto;
   color: #fff;
   background: #000;
   text-align: center;
   font-size: 16 px;
   line-height: 62px;
}
</style>
