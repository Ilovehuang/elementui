<template>
   <div class="form-main">
      <div class="left">
         <vp-widget-home-data></vp-widget-home-data>
         <vp-nav-homeicon></vp-nav-homeicon>
      </div>
      <div class="right">
         <vp-widget-home-ranking></vp-widget-home-ranking>
      </div>
      <div class="clear"></div>
         <vp-widget-home-chart></vp-widget-home-chart>

   </div>
</template>
<script>
Vue.component("vp-main-home-default", {
   template: template,
   props: [],
   data() {
   },
   computed: {
   },
   watch: {
   },
   methods: {
   },
   created() {
   },
   mounted() {},
});
</script>


<style lang="less">
@headerheight: 50px;

.form-main {
   margin: 0 23px;
   margin-top: 20px;
   &::after{
      content: "";
      display: block;
      clear: both;
   }
   .clear{
      clear: both;
   }
   &>.left,&>.right{
   }
   &>.left{
      width:65.5%;
      float: left;
   }
   &>.right{
      width: 32.6%;
      float: right;
   }
}
</style>
